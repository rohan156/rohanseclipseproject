import java.sql.Statement;

public class Commit {
	public static void main(String[] args) throws  Exception {
		Connection con = null;
		int i = 0;
		Statement pst = null;
		
		try {
			con = ConnectDB.dbconn();
			pst = 
		}
	}
}