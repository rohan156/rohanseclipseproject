import java.sql.DriverManager;
import java.sql.Connection;

public class Connect {
	public static Connection dbcon() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection c = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:rohandb","system","1234");
			
			return c;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public static void main(String[] args) {
		if(dbcon() != null) {
			System.out.println("Connect");
		}
	}
}